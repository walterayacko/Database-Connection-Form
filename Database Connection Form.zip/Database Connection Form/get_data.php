<?php
if (isset($_POST['name'])) {
    $name=$_POST['name'];
    $email=$_POST['email'];
    $fname=$_POST['fname'];
    $birthday_date=$_POST['birthday_date'];
    $sport=$_POST['sport'];
  
  $conx=mysqli_connect("localhost","root","","demo");
  $sql="INSERT INTO `info`(`name`, `email`,`fname`,`birthday_date`,`sport`) VALUES ('$name', '$email','$fname','$birthday_date','$sport');";
  $result=mysqli_query($conx,$sql);
  if ($result==true) {
    echo "<h3>Congratulations! Your Info has been Successfully updated 😊!</h3>";
  }
}
?>