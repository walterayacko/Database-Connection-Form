CREATE TABLE `info` (
  `id` int(11) NOT NULL,
  `name` varchar(30)  DEFAULT NULL,
  `email` varchar(20)  DEFAULT NULL,
  `fname` varchar(30)  DEFAULT NULL,   
  `birthday_date` varchar(200)  DEFAULT NULL,
  `sport` varchar(15) DEFAULT NULL
) AUTO_INCREMENT=5;

ALTER TABLE `info`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;






