<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Info Collection</title>
    <link rel="stylesheet" type="text/css" href="userinfo.css">
      <script>
    function Send_Data() {
      var name=document.getElementById("name").value;
      var email=document.getElementById("email").value;
      var fname=document.getElementById("fname").value;
      var birthday_date=document.getElementById("birthday_date").value;
      var sport=document.getElementById("sport").value;
      var httpr=new XMLHttpRequest();
      httpr.open("POST","get_data.php",true);
      httpr.setRequestHeader("Content-type","application/x-www-form-urlencoded");
      httpr.onreadystatechange=function(){
        if(httpr.readyState==4 && httpr.status==200){
          document.getElementById("response").innerHTML=httpr.responseText;

        }
      }
      httpr.send("name="+name+"&email="+email+"&fname="+fname+"&birthday_date="+birthday_date+"&sport="+sport);
    }
    
  </script>
</head>
<body>
       <h2>&nbsp;&nbsp;&nbsp;&nbsp;User Information Update Page</h2>
<main class="main-content">
  <section class="content-wrapper user-info-page">
   <form class="user-info">
     <div class="inputs-wrap">
     <p>
       <label for="name">First Name</label>
       <input type="text" id="name" placeholder="Enter your First name" required>
       <svg class="icon icon-checkmark-outline hidden success"><use xlink:href="#icon-checkmark-outline"></use></svg>
       <svg class="icon icon-close-outline hidden fail"><use xlink:href="#icon-close-outline"></use></svg>
      </p>
      <p>
       <label for="email">Email</label>
       <input type="text" id="email" placeholder="Enter your email address" required>
       <svg class="icon icon-checkmark-outline hidden success"><use xlink:href="#icon-checkmark-outline"></use></svg>
       <svg class="icon icon-close-outline hidden fail"><use xlink:href="#icon-close-outline"></use></svg>
      </p>
     <p>
       <label for="fname">Family name</label>
       <input type="text" id="fname" placeholder="Enter family or surname" required>
       <svg class="icon icon-checkmark-outline hidden success"><use xlink:href="#icon-checkmark-outline"></use></svg>
       <svg class="icon icon-close-outline hidden fail"><use xlink:href="#icon-close-outline"></use></svg>
      </p>

       <p>
       <label for="birthday_date">Birthday date</label>
       <input type="text" id="birthday_date" placeholder="Enter your date of birth" required>
       <svg class="icon icon-checkmark-outline hidden success"><use xlink:href="#icon-checkmark-outline"></use></svg>
       <svg class="icon icon-close-outline hidden fail"><use xlink:href="#icon-close-outline"></use></svg>
      </p>
      <p>
       <label for="birthday_date">Favourite sport</label>
       <select class="selectpicker" id="sport" >
<option value=""> Select favourite Sport </option>
<option value="Athletics">Athletics</option>
<option value="Basketball">Basketball</option>
<option value="Cricket">Cricket</option>
<option value="Football">Football</option>
<option value="Hockey">Hockey</option>
<option value="Swimming">Swimming</option>
<option value="Tennis">Tennis</option>
</select>
      </p>
      </div>
       <p class="sendinfo-btn-wrap">
            <input type="button" value="Submit" onclick="Send_Data()" /><br/>
        <span id="response">
       </p>
   </form> 
  </section>
</main>

   <svg aria-hidden="true" style="position: absolute; width: 0; height: 0; overflow: hidden;">
<defs>
<symbol id="icon-close-outline" viewBox="0 0 20 20">
<title>close-outline</title>
<path d="M2.93 17.070c-1.884-1.821-3.053-4.37-3.053-7.193 0-5.523 4.477-10 10-10 2.823 0 5.372 1.169 7.19 3.050l0.003 0.003c1.737 1.796 2.807 4.247 2.807 6.947 0 5.523-4.477 10-10 10-2.7 0-5.151-1.070-6.95-2.81l0.003 0.003zM4.34 15.66c1.449 1.449 3.45 2.344 5.66 2.344 4.421 0 8.004-3.584 8.004-8.004 0-2.21-0.896-4.211-2.344-5.66v0c-1.449-1.449-3.45-2.344-5.66-2.344-4.421 0-8.004 3.584-8.004 8.004 0 2.21 0.896 4.211 2.344 5.66v0zM14.24 7.17l-2.83 2.83 2.83 2.83-1.41 1.41-2.83-2.83-2.83 2.83-1.41-1.41 2.83-2.83-2.83-2.83 1.41-1.41 2.83 2.83 2.83-2.83 1.41 1.41z"></path>
</symbol>

<symbol id="icon-checkmark-outline" viewBox="0 0 20 20">
<title>checkmark-outline</title>
<path d="M2.93 17.070c-1.884-1.821-3.053-4.37-3.053-7.193 0-5.523 4.477-10 10-10 2.823 0 5.372 1.169 7.19 3.050l0.003 0.003c1.737 1.796 2.807 4.247 2.807 6.947 0 5.523-4.477 10-10 10-2.7 0-5.151-1.070-6.95-2.81l0.003 0.003zM15.66 15.66c1.449-1.449 2.344-3.45 2.344-5.66 0-4.421-3.584-8.004-8.004-8.004-2.21 0-4.211 0.896-5.66 2.344v0c-1.449 1.449-2.344 3.45-2.344 5.66 0 4.421 3.584 8.004 8.004 8.004 2.21 0 4.211-0.896 5.66-2.344v0zM6.7 9.29l2.3 2.31 4.3-4.3 1.4 1.42-5.7 5.68-3.7-3.7 1.4-1.42z"></path>
</symbol>
<symbol id="icon-users" viewBox="0 0 36 32">
<title>users</title>
<path d="M24 24.082v-1.649c2.203-1.241 4-4.337 4-7.432 0-4.971 0-9-6-9s-6 4.029-6 9c0 3.096 1.797 6.191 4 7.432v1.649c-6.784 0.555-12 3.888-12 7.918h28c0-4.030-5.216-7.364-12-7.918z"></path>
<path d="M10.225 24.854c1.728-1.13 3.877-1.989 6.243-2.513-0.47-0.556-0.897-1.176-1.265-1.844-0.95-1.726-1.453-3.627-1.453-5.497 0-2.689 0-5.228 0.956-7.305 0.928-2.016 2.598-3.265 4.976-3.734-0.529-2.39-1.936-3.961-5.682-3.961-6 0-6 4.029-6 9 0 3.096 1.797 6.191 4 7.432v1.649c-6.784 0.555-12 3.888-12 7.918h8.719c0.454-0.403 0.956-0.787 1.506-1.146z"></path>
</symbol>
<symbol id="icon-home3" viewBox="0 0 32 32">
<title>home3</title>
<path d="M32 19l-6-6v-9h-4v5l-6-6-16 16v1h4v10h10v-6h4v6h10v-10h4z"></path>
</symbol>
</defs>
</svg>
    <script>
      const birthdayDateField = document.getElementById('birthday_date');
const emailField = document.getElementById('email');
const nameField = document.getElementById('name');
const fnameField = document.getElementById('fname');
const formInputs = document.querySelectorAll('input');

const fieldsData = {
  birthdayField: {
    regex: /\d{2}-\d{2}-\d{4}/,
    message: 'Please enter date with the format: dd-mm-yyyy'
  },
  emailField: {
    regex: /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/,
    message: 'Please enter a correct email format: ab@cd.de/efg'
  },
  nameField: {
    regex: /^[ \u00c0-\u01ffa-zA-Z'\-]+$/,
    message: 'Please enter a valid First name: alphabetical characters',
  },
  fnameField: {
    regex: /^[ \u00c0-\u01ffa-zA-Z'\-]+$/,
    message: 'Please enter a valid Surname: alphabetical characters',
  },
};

/* Program Utilities */
const view = {
  createMessage(domPath, message) {
    const paragraph = document.createElement('p');
    paragraph.textContent = message;
    paragraph.className = 'error';
    domPath.insertAdjacentElement('afterend', paragraph);
  },

  checkIfErrorMessageExists(parentSibling) {
    if (parentSibling && parentSibling.className === 'error') {
      return true;
    }
    return false;
  },

  removeErrorMessage(parentSibling) {
    if (this.checkIfErrorMessageExists(parentSibling)) {
      parentSibling.remove();
    }
  },

  showInputIsValid(parent, target, parentSibling) {
    this.removeErrorMessage(parentSibling);
    // show checkmark icon
    parent.querySelector('.icon-checkmark-outline').classList.remove('hidden');
    target.classList.add('has-success');
    // remove close/error icon
    parent.querySelector('.icon-close-outline').classList.add('hidden');
    // remove error outline
    target.classList.remove('has-error');
  },

  showInputIsInvalid(parent, target, parentSibling, message) {
    if (!this.checkIfErrorMessageExists(parentSibling)) {
      this.createMessage(parent, message);
    }
    // hide error/checkmark icon
    parent.querySelector('.icon-checkmark-outline').classList.add('hidden');
    // show error icon
    parent.querySelector('.icon-close-outline').classList.remove('hidden');
    target.classList.add('has-error');
    target.classList.remove('has-success');
  },
  clearSuccessFormStyles() {
    nameField.classList.remove('has-success');
    fnameField.classList.remove('has-success');
    successIcons.forEach(icon => icon.classList.add('hidden'));
  },
};

const validators = {
  validateInput(regex, fieldValue) {
    if (regex.test(fieldValue)) {
      return true;
    }
    return false;
  },

  runValidator(dataField, parent, target, parentSibling, fieldInput) {
    const { regex, message } = dataField;
    const validate = validators.validateInput(regex, fieldInput.value);
    if (validate) {
      view.showInputIsValid(parent, target, parentSibling);
      return true;
    } 
    view.showInputIsInvalid(parent, target, parentSibling, message);
    
  },
};


function validateInput(event) {
  const target = event.target;
  const targetId = event.target.id;
  const parent = event.target.parentNode;
  const parentSibling = event.target.parentNode.nextElementSibling;
  switch (targetId) {
    case 'birthday_date':
      isBirthdayFieldValid = validators.runValidator(fieldsData.birthdayField, parent, target,
        parentSibling, birthdayDateField);
      break;
    case 'email':
      isemailFieldValid = validators.runValidator(fieldsData.emailField, parent, target,
        parentSibling, emailField);
      break;
    case 'name':
      isNameFieldValid = validators.runValidator(fieldsData.nameField, parent, target,
        parentSibling, nameField);
      break;
    case 'fname':
      isfnameFieldValid = validators.runValidator(fieldsData.fnameField, parent, target,
        parentSibling, fnameField);
      break;
    default:
      break;
  }

}

const eventsList = ['input', 'blur'];

formInputs.forEach(inputField => {
  for (let event of eventsList) {
    inputField.addEventListener(event, function(e) {
      validateInput(e);
    });

  }

});


    </script>
</body>
</html>
